<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$alertMessage = '';
$alertType = '';

if (isset($_GET['id'])) {
    $expense_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    $query = "DELETE FROM expenses WHERE id = '$expense_id' AND user_id = '$user_id'";
    if (mysqli_query($conn, $query)) {
        $alertMessage = "Expense deleted successfully!";
        $alertType = 'success';
    } else {
        $alertMessage = "Error deleting expense: " . mysqli_error($conn);
        $alertType = 'error';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Expense</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <h2>Delete Expense</h2>
    <p>Click below to confirm deletion.</p>
    <button class="btn btn-danger delete-expense" data-id="<?php echo $_GET['id'] ?? ''; ?>">Delete Expense</button>
    <?php if ($alertMessage): ?>
        <script>
            $(document).ready(function() {
                showAlert(<?php echo json_encode($alertMessage); ?>, '<?php echo $alertType; ?>', null, true);
                setTimeout(() => window.location.href = 'view_expenses.php', 2000);
            });
        </script>
    <?php endif; ?>
    <script>
        $('.delete-expense').click(function() {
            const expenseId = $(this).data('id');
            showAlert('Are you sure you want to delete this expense?', 'warning', function() {
                window.location.href = 'delete_expense.php?id=' + expenseId;
            });
        });
    </script>
    <?php include '../includes/footer.php'; ?>
</body>
</html>