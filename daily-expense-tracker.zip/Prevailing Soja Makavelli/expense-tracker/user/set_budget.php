<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = $_POST['category_id'];
    $amount = $_POST['amount'];
    $month = $_POST['month']; // Format: YYYY-MM

    $query = "INSERT INTO budgets (user_id, category_id, amount, month) 
              VALUES ('$user_id', '$category_id', '$amount', '$month')";
    if (mysqli_query($conn, $query)) {
        setAlert("Budget set successfully!", 'success', true);
        header("Location: view_budget.php");
        exit();
    } else {
        setAlert("Error: " . mysqli_error($conn), 'error');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Set Budget</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <h2>Set Budget</h2>
    <form method="POST">
        <div class="form-group">
            <label>Category</label>
            <select name="category_id" class="form-control" required>
                <?php
                $query = "SELECT * FROM categories WHERE user_id = '$user_id' OR is_global = TRUE";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='{$row['id']}'>{$row['name']}" . ($row['is_global'] ? " (Global)" : "") . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label>Budget Amount</label>
            <input type="number" step="0.01" name="amount" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Month</label>
            <input type="month" name="month" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Set Budget</button>
    </form>
    <?php include '../includes/footer.php'; ?>
</body>
</html>