<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$expense_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch expense details
$stmt = mysqli_prepare($conn, "
    SELECT e.id, e.category_id, e.amount, e.expense_date, e.description, c.name
    FROM expenses e
    JOIN categories c ON e.category_id = c.id
    WHERE e.id = ? AND e.user_id = ?
");
mysqli_stmt_bind_param($stmt, "ii", $expense_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    setAlert("Expense not found or you don't have permission to edit it.", 'error');
    header("Location: view_expenses.php");
    exit();
}

$expense = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Fetch categories for dropdown
$stmt = mysqli_prepare($conn, "SELECT id, name FROM categories WHERE user_id = ? OR is_global = TRUE");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$categories_result = mysqli_stmt_get_result($stmt);
$categories = [];
while ($row = mysqli_fetch_assoc($categories_result)) {
    $categories[] = $row;
}
mysqli_stmt_close($stmt);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = (int)$_POST['category_id'];
    $amount = trim($_POST['amount']);
    $expense_date = trim($_POST['expense_date']);
    $description = trim($_POST['description']);

    // Validate input
    if ($category_id <= 0) {
        setAlert("Please select a valid category.", 'error');
    } elseif (empty($amount) || $amount <= 0) {
        setAlert("Amount must be greater than zero.", 'error');
    } elseif (empty($expense_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expense_date)) {
        setAlert("Invalid date format. Use YYYY-MM-DD.", 'error');
    } else {
        // Update expense
        $stmt = mysqli_prepare($conn, "
            UPDATE expenses 
            SET category_id = ?, amount = ?, expense_date = ?, description = ?
            WHERE id = ? AND user_id = ?
        ");
        mysqli_stmt_bind_param($stmt, "idssii", $category_id, $amount, $expense_date, $description, $expense_id, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            setAlert("Expense updated successfully!", 'success', true);
            header("Location: view_expenses.php");
            exit();
        } else {
            setAlert("Error updating expense: " . mysqli_error($conn), 'error');
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Expense - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Edit Expense</h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="category_id">Category</label>
                <select name="category_id" id="category_id" class="form-control" required>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $expense['category_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['name']) . ($category['id'] ? '' : ' (Global)'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" name="amount" id="amount" class="form-control" step="0.01" min="0.01" value="<?php echo number_format($expense['amount'], 2); ?>" required>
            </div>
            <div class="form-group">
                <label for="expense_date">Date</label>
                <input type="date" name="expense_date" id="expense_date" class="form-control" value="<?php echo htmlspecialchars($expense['expense_date']); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" id="description" class="form-control"><?php echo htmlspecialchars($expense['description'] ?: ''); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Expense</button>
            <a href="view_expenses.php" class="btn btn-secondary">Back to Expenses</a>
        </form>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>