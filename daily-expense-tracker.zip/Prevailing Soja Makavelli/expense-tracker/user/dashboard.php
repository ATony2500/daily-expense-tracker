<?php
require '../includes/db.php';
require '../includes/check_budget.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$budgetAlerts = checkBudgetAlerts($conn, $user_id);

$query = "SELECT c.name, SUM(e.amount) as total 
          FROM expenses e 
          JOIN categories c ON e.category_id = c.id 
          WHERE e.user_id = '$user_id' 
          GROUP BY c.id";
$result = mysqli_query($conn, $query);
if (!$result) {
    setAlert("Error fetching expenses: " . mysqli_error($conn), 'error');
}
$categories = [];
$amounts = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row['name'];
    $amounts[] = $row['total'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <h2>Your Expense Overview</h2>
    <ul>
        <li><a href="add_expense.php">Add Expense</a></li>
        <li><a href="view_expenses.php">View Expenses</a></li>
        <li><a href="add_category.php">Add Category</a></li>
        <li><a href="set_budget.php">Set Budget</a></li>
    </ul>
    <?php if (empty($categories)): ?>
        <p>No expenses recorded yet.</p>
    <?php else: ?>
        <canvas id="userChart"></canvas>
    <?php endif; ?>
    <?php if ($budgetAlerts): ?>
        <script>
            $(document).ready(function() {
                <?php foreach ($budgetAlerts as $alert): ?>
                    showAlert(<?php echo json_encode($alert['message']); ?>, '<?php echo $alert['type']; ?>', null, true);
                <?php endforeach; ?>
            });
        </script>
    <?php endif; ?>
    <script>
        <?php if (!empty($categories)): ?>
        const ctx = document.getElementById('userChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($categories); ?>,
                datasets: [{
                    data: <?php echo json_encode($amounts); ?>,
                    backgroundColor: ['#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0']
                }]
            },
            options: {
                plugins: { title: { display: true, text: 'Your Expenses by Category' } }
            }
        });
        <?php endif; ?>
    </script>
    <?php include '../includes/footer.php'; ?>
</body>
</html>