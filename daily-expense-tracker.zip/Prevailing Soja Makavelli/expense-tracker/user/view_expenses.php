<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Initialize filter variables
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

// Build query with filters
$query = "SELECT e.id, e.expense_date, c.name as category, e.amount, e.description 
          FROM expenses e 
          JOIN categories c ON e.category_id = c.id 
          WHERE e.user_id = ?";
$params = [$user_id];
$types = "i";

if ($start_date) {
    $query .= " AND e.expense_date >= ?";
    $params[] = $start_date;
    $types .= "s";
}
if ($end_date) {
    $query .= " AND e.expense_date <= ?";
    $params[] = $end_date;
    $types .= "s";
}
if ($category_id) {
    $query .= " AND e.category_id = ?";
    $params[] = $category_id;
    $types .= "i";
}
$query .= " ORDER BY e.expense_date DESC";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$expenses = [];
while ($row = mysqli_fetch_assoc($result)) {
    $expenses[] = $row;
}
mysqli_stmt_close($stmt);

// Fetch categories for filter dropdown
$stmt = mysqli_prepare($conn, "SELECT id, name FROM categories WHERE user_id = ? OR is_global = TRUE");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$categories_result = mysqli_stmt_get_result($stmt);
$categories = [];
while ($row = mysqli_fetch_assoc($categories_result)) {
    $categories[] = $row;
}
mysqli_stmt_close($stmt);

// Data for pie chart
$chart_query = "SELECT c.name, SUM(e.amount) as total 
                FROM expenses e 
                JOIN categories c ON e.category_id = c.id 
                WHERE e.user_id = ?";
$chart_params = [$user_id];
$chart_types = "i";

if ($start_date) {
    $chart_query .= " AND e.expense_date >= ?";
    $chart_params[] = $start_date;
    $chart_types .= "s";
}
if ($end_date) {
    $chart_query .= " AND e.expense_date <= ?";
    $chart_params[] = $end_date;
    $chart_types .= "s";
}
if ($category_id) {
    $chart_query .= " AND e.category_id = ?";
    $chart_params[] = $category_id;
    $chart_types .= "i";
}
$chart_query .= " GROUP BY c.id";

$stmt = mysqli_prepare($conn, $chart_query);
mysqli_stmt_bind_param($stmt, $chart_types, ...$chart_params);
mysqli_stmt_execute($stmt);
$chart_result = mysqli_stmt_get_result($stmt);

$chart_labels = [];
$chart_data = [];
while ($row = mysqli_fetch_assoc($chart_result)) {
    $chart_labels[] = $row['name'];
    $chart_data[] = $row['total'];
}
mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Expenses - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Your Expenses</h2>

        <!-- Filter Form -->
        <form method="GET" class="mt-4">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="start_date">Start Date</label>
                        <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="end_date">End Date</label>
                        <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="category_id">Category</label>
                        <select name="category_id" id="category_id" class="form-control">
                            <option value="0">All Categories</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo $category_id == $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']) . ($category['id'] ? '' : ' (Global)'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="submit" class="btn btn-primary btn-block">Filter</button>
                    </div>
                </div>
            </div>
        </form>

        <!-- Expenses Table -->
        <?php if (empty($expenses)): ?>
            <p class="mt-4">No expenses found. <a href="add_expense.php">Add an expense</a>.</p>
        <?php else: ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($expenses as $expense): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($expense['expense_date']); ?></td>
                            <td><?php echo htmlspecialchars($expense['category']); ?></td>
                            <td>$<?php echo number_format($expense['amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($expense['description'] ?: 'N/A'); ?></td>
                            <td>
                                <a href="edit_expense.php?id=<?php echo $expense['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <button class="btn btn-sm btn-danger delete-expense" data-id="<?php echo $expense['id']; ?>">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <!-- Expense Chart -->
        <?php if (!empty($chart_data)): ?>
            <h3 class="mt-5">Expense Breakdown by Category</h3>
            <canvas id="expenseChart" style="max-height: 400px;"></canvas>
        <?php endif; ?>

        <!-- Link to Add Expense -->
        <a href="add_expense.php" class="btn btn-primary mt-3">Add New Expense</a>
    </div>

    <!-- JavaScript for Chart and Delete Confirmation -->
    <script>
        <?php if (!empty($chart_data)): ?>
        const ctx = document.getElementById('expenseChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($chart_labels); ?>,
                datasets: [{
                    label: 'Expenses by Category',
                    data: <?php echo json_encode($chart_data); ?>,
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF']
                }]
            },
            options: {
                plugins: {
                    title: { display: true, text: 'Expenses by Category' }
                }
            }
        });
        <?php endif; ?>

        // Delete expense confirmation
        $('.delete-expense').click(function() {
            const expenseId = $(this).data('id');
            showAlert('Are you sure you want to delete this expense?', 'warning', function() {
                window.location.href = 'delete_expense.php?id=' + expenseId;
            });
        });
    </script>
    <?php include '../includes/footer.php'; ?>
</body>
</html>