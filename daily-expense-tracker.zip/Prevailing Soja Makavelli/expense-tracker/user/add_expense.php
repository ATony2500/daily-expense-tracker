<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$alertMessage = '';
$alertType = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $category_id = $_POST['category_id'];
    $amount = $_POST['amount'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $expense_date = $_POST['expense_date'];

    // Check budget limit
    $month = date('Ym', strtotime($expense_date));
    $query = "SELECT amount FROM budgets WHERE user_id = '$user_id' AND category_id = '$category_id' AND month = '$month'";
    $result = mysqli_query($conn, $query);
    $budget = mysqli_fetch_assoc($result)['amount'] ?? 0;

    $query = "SELECT SUM(amount) as total FROM expenses WHERE user_id = '$user_id' AND category_id = '$category_id' AND DATE_FORMAT(expense_date, '%Y%m') = '$month'";
    $result = mysqli_query($conn, $query);
    $totalSpent = mysqli_fetch_assoc($result)['total'] ?? 0;

    if ($budget > 0 && ($totalSpent + $amount) > $budget) {
        $alertMessage = "Warning: Adding this expense will exceed your budget of $$budget for this category!";
        $alertType = 'warning';
    } else {
        $query = "INSERT INTO expenses (user_id, category_id, amount, description, expense_date) 
                  VALUES ('$user_id', '$category_id', '$amount', '$description', '$expense_date')";
        if (mysqli_query($conn, $query)) {
            $alertMessage = "Expense added successfully!";
            $alertType = 'success';
        } else {
            $alertMessage = "Error: " . mysqli_error($conn);
            $alertType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Expense</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <h2>Add Expense</h2>
    <form method="POST" id="expenseForm">
        <div class="form-group">
            <label>Category</label>
            <select name="category_id" class="form-control" required>
                <?php
                $user_id = $_SESSION['user_id'];
                $query = "SELECT * FROM categories WHERE user_id = '$user_id' OR is_global = TRUE";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='{$row['id']}'>{$row['name']}" . ($row['is_global'] ? " (Global)" : "") . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label>Amount</label>
            <input type="number" step="0.01" name="amount" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Description</label>
            <input type="text" name="description" class="form-control">
        </div>
        <div class="form-group">
            <label>Date</label>
            <input type="date" name="expense_date" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Expense</button>
    </form>
    <?php if ($alertMessage): ?>
        <script>
            $(document).ready(function() {
                showAlert(<?php echo json_encode($alertMessage); ?>, '<?php echo $alertType; ?>');
            });
        </script>
    <?php endif; ?>
    <?php include '../includes/footer.php'; ?>
</body>
</html>