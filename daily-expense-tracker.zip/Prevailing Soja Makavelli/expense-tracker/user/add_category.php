<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    
    // Validate input
    if (empty($name)) {
        setAlert("Category name cannot be empty.", 'error');
    } elseif (strlen($name) > 50) {
        setAlert("Category name must be 50 characters or less.", 'error');
    } else {
        // Check if category already exists for the user
        $stmt = mysqli_prepare($conn, "SELECT id FROM categories WHERE name = ? AND (user_id = ? OR is_global = TRUE)");
        mysqli_stmt_bind_param($stmt, "si", $name, $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            setAlert("Category '$name' already exists.", 'error');
        } else {
            // Insert new category
            $stmt = mysqli_prepare($conn, "INSERT INTO categories (user_id, name, is_global) VALUES (?, ?, FALSE)");
            mysqli_stmt_bind_param($stmt, "is", $user_id, $name);
            if (mysqli_stmt_execute($stmt)) {
                setAlert("Category '$name' added successfully!", 'success', true);
                header("Location: add_category.php");
                exit();
            } else {
                setAlert("Error adding category: " . mysqli_error($conn), 'error');
            }
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Add New Category</h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" name="name" id="name" class="form-control" required maxlength="50" placeholder="Enter category name">
            </div>
            <button type="submit" class="btn btn-primary">Add Category</button>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </form>

        <!-- Display existing user categories -->
        <h3 class="mt-5">Your Categories</h3>
        <?php
        $stmt = mysqli_prepare($conn, "SELECT id, name FROM categories WHERE user_id = ? AND is_global = FALSE");
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            echo '<ul class="list-group">';
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<li class="list-group-item">' . htmlspecialchars($row['name']) . '</li>';
            }
            echo '</ul>';
        } else {
            echo '<p>No personal categories added yet.</p>';
        }
        mysqli_stmt_close($stmt);
        ?>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>