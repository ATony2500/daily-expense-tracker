<?php
require '../includes/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$budget_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch budget details
$stmt = mysqli_prepare($conn, "
    SELECT b.id, b.category_id, b.amount, b.month, c.name
    FROM budgets b
    JOIN categories c ON b.category_id = c.id
    WHERE b.id = ? AND b.user_id = ?
");
mysqli_stmt_bind_param($stmt, "ii", $budget_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    setAlert("Budget not found or you don't have permission to edit it.", 'error');
    header("Location: view_budget.php");
    exit();
}

$budget = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = trim($_POST['amount']);
    $month = trim($_POST['month']); // Expected format: YYYY-MM

    // Validate input
    if (empty($amount) || $amount <= 0) {
        setAlert("Budget amount must be greater than zero.", 'error');
    } elseif (!preg_match('/^\d{4}-\d{2}$/', $month)) {
        setAlert("Invalid month format. Use YYYY-MM.", 'error');
    } else {
        // Convert month to YYYYMM for storage
        $month_formatted = str_replace('-', '', $month);
        
        // Update budget
        $stmt = mysqli_prepare($conn, "UPDATE budgets SET amount = ?, month = ? WHERE id = ? AND user_id = ?");
        mysqli_stmt_bind_param($stmt, "dsii", $amount, $month_formatted, $budget_id, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            setAlert("Budget updated successfully!", 'success', true);
            header("Location: view_budget.php");
            exit();
        } else {
            setAlert("Error updating budget: " . mysqli_error($conn), 'error');
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Budget - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Edit Budget for <?php echo htmlspecialchars($budget['name']); ?></h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="category">Category</label>
                <input type="text" id="category" class="form-control" value="<?php echo htmlspecialchars($budget['name']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="amount">Budget Amount</label>
                <input type="number" name="amount" id="amount" class="form-control" step="0.01" min="0.01" value="<?php echo number_format($budget['amount'], 2); ?>" required>
            </div>
            <div class="form-group">
                <label for="month">Month</label>
                <input type="month" name="month" id="month" class="form-control" value="<?php echo substr($budget['month'], 0, 4) . '-' . substr($budget['month'], 4, 2); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Budget</button>
            <a href="view_budget.php" class="btn btn-secondary">Back to Budgets</a>
        </form>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>