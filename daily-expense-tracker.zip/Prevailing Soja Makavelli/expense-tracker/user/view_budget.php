<?php
require '../includes/db.php';
require '../includes/check_budget.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$currentMonth = date('Ym'); // Format: YYYYMM (e.g., 202509)

// Fetch budget and spending data
$stmt = mysqli_prepare($conn, "
    SELECT b.id, b.category_id, c.name, b.amount as budget, COALESCE(SUM(e.amount), 0) as total_spent
    FROM budgets b
    LEFT JOIN expenses e ON b.category_id = e.category_id AND b.user_id = e.user_id AND DATE_FORMAT(e.expense_date, '%Y%m') = ?
    JOIN categories c ON b.category_id = c.id
    WHERE b.user_id = ? AND b.month = ?
    GROUP BY b.id, b.category_id, c.name, b.amount
");
mysqli_stmt_bind_param($stmt, "sis", $currentMonth, $user_id, $currentMonth);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$budgets = [];
$chartLabels = [];
$chartSpent = [];
$chartRemaining = [];
while ($row = mysqli_fetch_assoc($result)) {
    $remaining = $row['budget'] - $row['total_spent'];
    $budgets[] = [
        'id' => $row['id'],
        'category' => $row['name'],
        'budget' => $row['budget'],
        'total_spent' => $row['total_spent'],
        'remaining' => $remaining
    ];
    $chartLabels[] = $row['name'];
    $chartSpent[] = $row['total_spent'];
    $chartRemaining[] = max(0, $remaining); // Avoid negative values in chart
}
mysqli_stmt_close($stmt);

// Check for budget alerts
$budgetAlerts = checkBudgetAlerts($conn, $user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Budgets - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Your Budgets for <?php echo date('F Y', strtotime($currentMonth . '01')); ?></h2>
        
        <!-- Budget Table -->
        <?php if (empty($budgets)): ?>
            <p class="mt-4">No budgets set for this month. <a href="set_budget.php">Set a budget</a>.</p>
        <?php else: ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Budget Amount</th>
                        <th>Spent</th>
                        <th>Remaining</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($budgets as $budget): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($budget['category']); ?></td>
                            <td>$<?php echo number_format($budget['budget'], 2); ?></td>
                            <td>$<?php echo number_format($budget['total_spent'], 2); ?></td>
                            <td class="<?php echo $budget['remaining'] < 0 ? 'text-danger' : ''; ?>">
                                $<?php echo number_format($budget['remaining'], 2); ?>
                            </td>
                            <td>
                                <a href="edit_budget.php?id=<?php echo $budget['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <button class="btn btn-sm btn-danger delete-budget" data-id="<?php echo $budget['id']; ?>">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <!-- Budget Chart -->
        <?php if (!empty($budgets)): ?>
            <h3 class="mt-5">Budget Overview</h3>
            <canvas id="budgetChart" style="max-height: 400px;"></canvas>
        <?php endif; ?>

        <!-- Link to Set Budget -->
        <a href="set_budget.php" class="btn btn-primary mt-3">Set New Budget</a>
    </div>

    <!-- Modal Alerts -->
    <?php if ($budgetAlerts): ?>
        <script>
            $(document).ready(function() {
                <?php foreach ($budgetAlerts as $alert): ?>
                    showAlert(<?php echo json_encode($alert['message']); ?>, '<?php echo $alert['type']; ?>', null, true);
                <?php endforeach; ?>
            });
        </script>
    <?php endif; ?>
    <script>
        <?php if (!empty($budgets)): ?>
        const ctx = document.getElementById('budgetChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($chartLabels); ?>,
                datasets: [
                    {
                        label: 'Spent',
                        data: <?php echo json_encode($chartSpent); ?>,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'],
                    },
                    {
                        label: 'Remaining',
                        data: <?php echo json_encode($chartRemaining); ?>,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'].map(color => color + '66'), // Semi-transparent
                    }
                ]
            },
            options: {
                plugins: {
                    title: { display: true, text: 'Budget vs. Spending by Category' }
                }
            }
        });
        <?php endif; ?>

        // Delete budget confirmation
        $('.delete-budget').click(function() {
            const budgetId = $(this).data('id');
            showAlert('Are you sure you want to delete this budget?', 'warning', function() {
                window.location.href = 'delete_budget.php?id=' + budgetId;
            });
        });
    </script>
    <?php include '../includes/footer.php'; ?>
</body>
</html>