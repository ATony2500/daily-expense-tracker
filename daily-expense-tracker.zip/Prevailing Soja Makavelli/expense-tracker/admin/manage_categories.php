<?php
require '../includes/db.php';
restrictToAdmin();

// Fetch all global categories
$stmt = mysqli_prepare($conn, "SELECT id, name FROM categories WHERE is_global = TRUE ORDER BY name");
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$categories = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row;
}
mysqli_stmt_close($stmt);

// Handle add category form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $name = trim($_POST['name']);

    // Validate input
    if (empty($name) || strlen($name) < 3) {
        setAlert("Category name must be at least 3 characters long.", 'error');
    } elseif (strlen($name) > 50) {
        setAlert("Category name cannot exceed 50 characters.", 'error');
    } else {
        // Check for duplicate category name
        $stmt = mysqli_prepare($conn, "SELECT id FROM categories WHERE name = ? AND is_global = TRUE");
        mysqli_stmt_bind_param($stmt, "s", $name);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            setAlert("Category name already exists.", 'error');
        } else {
            // Add new global category
            $stmt = mysqli_prepare($conn, "INSERT INTO categories (name, is_global) VALUES (?, TRUE)");
            mysqli_stmt_bind_param($stmt, "s", $name);
            if (mysqli_stmt_execute($stmt)) {
                setAlert("Category added successfully!", 'success', true);
            } else {
                setAlert("Error adding category: " . mysqli_error($conn), 'error');
            }
        }
        mysqli_stmt_close($stmt);
    }
    header("Location: manage_categories.php");
    exit();
}

// Handle delete category action
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete' && isset($_POST['category_id'])) {
    $category_id = (int)$_POST['category_id'];

    // Check if category is global
    $stmt = mysqli_prepare($conn, "SELECT id FROM categories WHERE id = ? AND is_global = TRUE");
    mysqli_stmt_bind_param($stmt, "i", $category_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($result) === 0) {
        setAlert("Category not found or not global.", 'error');
    } else {
        // Delete category
        $stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE id = ? AND is_global = TRUE");
        mysqli_stmt_bind_param($stmt, "i", $category_id);
        if (mysqli_stmt_execute($stmt)) {
            setAlert("Category deleted successfully!", 'success', true);
        } else {
            setAlert("Error deleting category: " . mysqli_error($conn), 'error');
        }
    }
    mysqli_stmt_close($stmt);
    header("Location: manage_categories.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Global Categories - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Manage Global Categories</h2>

        <!-- Add Category Form -->
        <h4 class="mt-4">Add New Global Category</h4>
        <form method="POST" class="mt-3">
            <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" name="name" id="name" class="form-control" maxlength="50" required>
            </div>
            <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
        </form>

        <!-- Categories Table -->
        <?php if (empty($categories)): ?>
            <p class="mt-4">No global categories found.</p>
        <?php else: ?>
            <h4 class="mt-5">Global Categories</h4>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($category['name']); ?></td>
                            <td>
                                <a href="edit_category.php?id=<?php echo $category['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <button class="btn btn-sm btn-danger delete-category" data-id="<?php echo $category['id']; ?>" data-action="delete">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
    </div>

    <!-- JavaScript for delete confirmation -->
    <script>
        $('.delete-category').click(function() {
            const categoryId = $(this).data('id');
            showAlert('Are you sure you want to delete this category? This action cannot be undone.', 'warning', function() {
                $('<form method="POST"/>')
                    .append(`<input type="hidden" name="category_id" value="${categoryId}">`)
                    .append(`<input type="hidden" name="action" value="delete">`)
                    .appendTo('body')
                    .submit();
            });
        });
    </script>
    <?php include '../includes/footer.php'; ?>
</body>
</html>