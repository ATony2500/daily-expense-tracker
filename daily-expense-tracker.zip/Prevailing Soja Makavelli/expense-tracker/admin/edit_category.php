<?php
require '../includes/db.php';
restrictToAdmin();

$category_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch category details
$stmt = mysqli_prepare($conn, "SELECT id, name FROM categories WHERE id = ? AND is_global = TRUE");
mysqli_stmt_bind_param($stmt, "i", $category_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    setAlert("Category not found or not global.", 'error');
    header("Location: manage_categories.php");
    exit();
}

$category = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);

    // Validate input
    if (empty($name) || strlen($name) < 3) {
        setAlert("Category name must be at least 3 characters long.", 'error');
    } elseif (strlen($name) > 50) {
        setAlert("Category name cannot exceed 50 characters.", 'error');
    } else {
        // Check for duplicate category name (excluding current category)
        $stmt = mysqli_prepare($conn, "SELECT id FROM categories WHERE name = ? AND is_global = TRUE AND id != ?");
        mysqli_stmt_bind_param($stmt, "si", $name, $category_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            setAlert("Category name already exists.", 'error');
        } else {
            // Update category
            $stmt = mysqli_prepare($conn, "UPDATE categories SET name = ? WHERE id = ? AND is_global = TRUE");
            mysqli_stmt_bind_param($stmt, "si", $name, $category_id);
            if (mysqli_stmt_execute($stmt)) {
                setAlert("Category updated successfully!", 'success', true);
                header("Location: manage_categories.php");
                exit();
            } else {
                setAlert("Error updating category: " . mysqli_error($conn), 'error');
            }
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Global Category - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Edit Global Category: <?php echo htmlspecialchars($category['name']); ?></h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($category['name']); ?>" maxlength="50" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Category</button>
            <a href="manage_categories.php" class="btn btn-secondary">Back to Manage Categories</a>
        </form>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>