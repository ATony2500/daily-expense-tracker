<?php
require '../includes/db.php';
restrictToAdmin();

$user_id = $_SESSION['user_id'];
$edit_user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Prevent admins from editing their own account
if ($edit_user_id == $user_id) {
    setAlert("You cannot edit your own account.", 'error');
    header("Location: manage_users.php");
    exit();
}

// Fetch user details
$stmt = mysqli_prepare($conn, "SELECT id, username, email, role, status FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $edit_user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    setAlert("User not found.", 'error');
    header("Location: manage_users.php");
    exit();
}

$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $status = $_POST['status'];

    // Validate input
    if (empty($username) || strlen($username) < 3) {
        setAlert("Username must be at least 3 characters long.", 'error');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        setAlert("Invalid email format.", 'error');
    } elseif (!in_array($role, ['user', 'admin'])) {
        setAlert("Invalid role selected.", 'error');
    } elseif (!in_array($status, ['active', 'suspended'])) {
        setAlert("Invalid status selected.", 'error');
    } else {
        // Check for duplicate username or email (excluding current user)
        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        mysqli_stmt_bind_param($stmt, "ssi", $username, $email, $edit_user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            setAlert("Username or email is already taken.", 'error');
        } else {
            // Update user
            $stmt = mysqli_prepare($conn, "UPDATE users SET username = ?, email = ?, role = ?, status = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "ssssi", $username, $email, $role, $status, $edit_user_id);
            if (mysqli_stmt_execute($stmt)) {
                setAlert("User updated successfully!", 'success', true);
                header("Location: manage_users.php");
                exit();
            } else {
                setAlert("Error updating user: " . mysqli_error($conn), 'error');
            }
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Edit User: <?php echo htmlspecialchars($user['username']); ?></h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" class="form-control" required>
                    <option value="user" <?php echo $user['role'] == 'user' ? 'selected' : ''; ?>>User</option>
                    <option value="admin" <?php echo $user['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                </select>
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select name="status" id="status" class="form-control" required>
                    <option value="active" <?php echo $user['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="suspended" <?php echo $user['status'] == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update User</button>
            <a href="manage_users.php" class="btn btn-secondary">Back to Manage Users</a>
        </form>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>