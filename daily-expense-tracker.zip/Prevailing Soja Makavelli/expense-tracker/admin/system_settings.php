<?php
require '../includes/db.php';
restrictToAdmin();

// Fetch current settings
$stmt = mysqli_prepare($conn, "SELECT setting_key, setting_value FROM settings");
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$settings = [];
while ($row = mysqli_fetch_assoc($result)) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
mysqli_stmt_close($stmt);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $default_currency = trim($_POST['default_currency']);
    $max_budget_limit = trim($_POST['max_budget_limit']);
    $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;

    // Validate input
    if (!in_array($default_currency, ['USD', 'EUR', 'NGN', 'GBP'])) {
        setAlert("Invalid currency selected.", 'error');
    } elseif (!is_numeric($max_budget_limit) || $max_budget_limit <= 0 || $max_budget_limit > 1000000) {
        setAlert("Maximum budget limit must be a positive number up to 1,000,000.", 'error');
    } else {
        // Update settings
        $stmt = mysqli_prepare($conn, "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()");
        $updates = [
            ['default_currency', $default_currency],
            ['max_budget_limit', $max_budget_limit],
            ['email_notifications', $email_notifications]
        ];
        $success = true;
        foreach ($updates as $update) {
            mysqli_stmt_bind_param($stmt, "sss", $update[0], $update[1], $update[1]);
            if (!mysqli_stmt_execute($stmt)) {
                $success = false;
                setAlert("Error updating setting {$update[0]}: " . mysqli_error($conn), 'error');
                break;
            }
        }
        mysqli_stmt_close($stmt);
        if ($success) {
            setAlert("System settings updated successfully!", 'success', true);
            header("Location: system_settings.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>System Settings</h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="default_currency">Default Currency</label>
                <select name="default_currency" id="default_currency" class="form-control" required>
                    <option value="USD" <?php echo ($settings['default_currency'] ?? 'USD') == 'USD' ? 'selected' : ''; ?>>USD</option>
                    <option value="EUR" <?php echo ($settings['default_currency'] ?? 'USD') == 'EUR' ? 'selected' : ''; ?>>EUR</option>
                    <option value="NGN" <?php echo ($settings['default_currency'] ?? 'USD') == 'NGN' ? 'selected' : ''; ?>>NGN</option>
                    <option value="GBP" <?php echo ($settings['default_currency'] ?? 'USD') == 'GBP' ? 'selected' : ''; ?>>GBP</option>
                </select>
            </div>
            <div class="form-group">
                <label for="max_budget_limit">Maximum Budget Limit (per user per month)</label>
                <input type="number" name="max_budget_limit" id="max_budget_limit" class="form-control" value="<?php echo htmlspecialchars($settings['max_budget_limit'] ?? '10000'); ?>" min="1" max="1000000" required>
            </div>
            <div class="form-group">
                <label for="email_notifications">Enable Email Notifications for Budget Alerts</label>
                <input type="checkbox" name="email_notifications" id="email_notifications" <?php echo ($settings['email_notifications'] ?? '1') == '1' ? 'checked' : ''; ?>>
            </div>
            <button type="submit" class="btn btn-primary">Update Settings</button>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </form>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>