<?php
require '../includes/db.php';
restrictToAdmin();

// Fetch all users
$stmt = mysqli_prepare($conn, "SELECT id, username, email, role, status FROM users ORDER BY username");
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}
mysqli_stmt_close($stmt);

// Handle suspend/unsuspend actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && isset($_POST['user_id'])) {
    $user_id = (int)$_POST['user_id'];
    $action = $_POST['action'];

    // Prevent admins from suspending/deleting themselves
    if ($user_id == $_SESSION['user_id']) {
        setAlert("You cannot modify your own account.", 'error');
        header("Location: manage_users.php");
        exit();
    }

    if ($action == 'suspend' || $action == 'unsuspend') {
        $status = ($action == 'suspend') ? 'suspended' : 'active';
        $stmt = mysqli_prepare($conn, "UPDATE users SET status = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "si", $status, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            setAlert("User " . ($action == 'suspend' ? 'suspended' : 'unsuspended') . " successfully!", 'success', true);
        } else {
            setAlert("Error updating user status: " . mysqli_error($conn), 'error');
        }
        mysqli_stmt_close($stmt);
    } elseif ($action == 'delete') {
        $stmt = mysqli_prepare($conn, "DELETE FROM users WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        if (mysqli_stmt_execute($stmt)) {
            setAlert("User deleted successfully!", 'success', true);
        } else {
            setAlert("Error deleting user: " . mysqli_error($conn), 'error');
        }
        mysqli_stmt_close($stmt);
    }
    header("Location: manage_users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <h2>Manage Users</h2>
        <?php if (empty($users)): ?>
            <p class="mt-4">No users found.</p>
        <?php else: ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                            <td><?php echo htmlspecialchars($user['status']); ?></td>
                            <td>
                                <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <?php if ($user['status'] == 'active'): ?>
                                    <button class="btn btn-sm btn-warning suspend-user" data-id="<?php echo $user['id']; ?>" data-action="suspend">Suspend</button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success unsuspend-user" data-id="<?php echo $user['id']; ?>" data-action="unsuspend">Unsuspend</button>
                                <?php endif; ?>
                                <button class="btn btn-sm btn-danger delete-user" data-id="<?php echo $user['id']; ?>" data-action="delete">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
    </div>

    <!-- JavaScript for action confirmations -->
    <script>
        $('.suspend-user, .unsuspend-user').click(function() {
            const userId = $(this).data('id');
            const action = $(this).data('action');
            const actionText = action === 'suspend' ? 'suspend' : 'unsuspend';
            showAlert(`Are you sure you want to ${actionText} this user?`, 'warning', function() {
                $('<form method="POST"/>')
                    .append(`<input type="hidden" name="user_id" value="${userId}">`)
                    .append(`<input type="hidden" name="action" value="${action}">`)
                    .appendTo('body')
                    .submit();
            });
        });

        $('.delete-user').click(function() {
            const userId = $(this).data('id');
            showAlert('Are you sure you want to delete this user? This action cannot be undone.', 'warning', function() {
                $('<form method="POST"/>')
                    .append(`<input type="hidden" name="user_id" value="${userId}">`)
                    .append(`<input type="hidden" name="action" value="delete">`)
                    .appendTo('body')
                    .submit();
            });
        });
    </script>
    <?php include '../includes/footer.php'; ?>
</body>
</html>