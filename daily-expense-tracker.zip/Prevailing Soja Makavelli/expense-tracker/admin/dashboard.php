<?php
require '../includes/db.php';
restrictToAdmin();

$query = "SELECT c.name, SUM(e.amount) as total 
          FROM expenses e 
          JOIN categories c ON e.category_id = c.id 
          GROUP BY c.id";
$result = mysqli_query($conn, $query);
$categories = [];
$amounts = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row['name'];
    $amounts[] = $row['total'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <h2>Admin Dashboard - System Overview</h2>
        <ul>
            <li><a href="manage_users.php">Manage Users</a></li>
            <li><a href="manage_categories.php">Manage Global Categories</a></li>
            <li><a href="system_settings.php">System Settings</a></li>
        </ul>
        <h3>Total Expenses by Category (All Users)</h3>
        <canvas id="adminChart"></canvas>
    </div>
    <script>
        const ctx = document.getElementById('adminChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($categories); ?>,
                datasets: [{
                    label: 'Total Expenses',
                    data: <?php echo json_encode($amounts); ?>,
                    backgroundColor: '#36A2EB'
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Amount (USD)' } },
                    x: { title: { display: true, text: 'Category' } }
                },
                plugins: { title: { display: true, text: 'System-Wide Expenses' } }
            }
        });
    </script>
</body>
</html>