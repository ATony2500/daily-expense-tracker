<?php
require 'includes/db.php';

// Redirect authenticated users to their respective dashboards
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: user/dashboard.php");
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker - Home</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <!--  -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="../index.php">Expense Tracker</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                
                    <li class="nav-item"><a class="nav-link" href="auth/login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="auth/register.php">Register</a></li>
            </ul>
        </div>
    </nav>
    <div class="container mt-4">
    <?php include 'includes/modals.php'; ?>
    <?php displayAlert(); ?>
<!--  -->
    <div class="container">
        <div class="jumbotron mt-4 text-center">
            <h1 class="display-4">Welcome to Daily Expense Tracker</h1>
            <p class="lead">Manage your finances with ease. Track expenses, set budgets, and gain insights into your spending habits.</p>
            <hr class="my-4">
            <p>Get started by creating an account or logging in.</p>
            <a class="btn btn-primary btn-lg mr-2" href="auth/register.php" role="button">Register</a>
            <a class="btn btn-success btn-lg" href="auth/login.php" role="button">Login</a>
        </div>

        <div class="row mt-5">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Track Expenses</h5>
                        <p class="card-text">Easily log your daily expenses and categorize them for better organization.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Set Budgets</h5>
                        <p class="card-text">Create monthly budgets and receive alerts to stay on track.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Visual Reports</h5>
                        <p class="card-text">View spending trends with interactive charts and summaries.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>