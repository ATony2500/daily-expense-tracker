<?php
function checkBudgetAlerts($conn, $user_id) {
    $alerts = [];
    $currentMonth = date('Ym');
    $query = "SELECT b.category_id, c.name, b.amount as budget, COALESCE(SUM(e.amount), 0) as total_spent
              FROM budgets b
              LEFT JOIN expenses e ON b.category_id = e.category_id AND b.user_id = e.user_id AND DATE_FORMAT(e.expense_date, '%Y%m') = ?
              JOIN categories c ON b.category_id = c.id
              WHERE b.user_id = ? AND b.month = ?
              GROUP BY b.category_id";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sis", $currentMonth, $user_id, $currentMonth);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        error_log("Query failed: " . mysqli_error($conn));
        return $alerts;
    }
    while ($row = mysqli_fetch_assoc($result)) {
        $total_spent = $row['total_spent'];
        $budget = $row['budget'];
        $percentage = ($budget > 0) ? ($total_spent / $budget) * 100 : 0;
        if ($percentage >= 100) {
            $alerts[] = [
                'message' => "You have exceeded your {$row['name']} budget of $$budget (spent $$total_spent)!",
                'type' => 'error'
            ];
        } elseif ($percentage >= 80) {
            $alerts[] = [
                'message' => "Warning: You have spent $$total_spent, reaching " . round($percentage) . "% of your {$row['name']} budget!",
                'type' => 'warning'
            ];
        } elseif ($percentage >= 50) {
            $alerts[] = [
                'message' => "Notice: You have spent $$total_spent, " . round($percentage) . "% of your {$row['name']} budget.",
                'type' => 'info'
            ];
        }
    }
    mysqli_stmt_close($stmt);
    return $alerts;
}
?>