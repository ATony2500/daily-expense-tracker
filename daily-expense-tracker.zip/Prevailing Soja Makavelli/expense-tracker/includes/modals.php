<div class="modal fade" id="alertModal" tabindex="-1" role="dialog" aria-labelledby="alertModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" role="alertdialog">
            <div class="modal-header">
                <h5 class="modal-title" id="alertModalLabel">Alert</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="alertModalBody" aria-live="polite"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="alertModalConfirm" style="display: none;">Confirm</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let alertQueue = [];

function showAlert(message, type = 'info', confirmCallback = null, autoClose = false) {
    alertQueue.push({ message, type, confirmCallback, autoClose });
    processAlertQueue();
}

function processAlertQueue() {
    if (alertQueue.length === 0 || $('#alertModal').hasClass('show')) return;

    const alert = alertQueue.shift();
    const { message, type, confirmCallback, autoClose } = alert;

    $('#alertModalBody').text(message);
    $('#alertModalLabel').text(type.charAt(0).toUpperCase() + type.slice(1));

    const header = $('.modal-header');
    header.removeClass('bg-info bg-success bg-warning bg-danger text-white');
    if (type === 'success') header.addClass('bg-success text-white');
    else if (type === 'warning') header.addClass('bg-warning');
    else if (type === 'error') header.addClass('bg-danger text-white');
    else header.addClass('bg-info text-white');

    if (confirmCallback) {
        $('#alertModalConfirm').show().off('click').on('click', function() {
            confirmCallback();
            $('#alertModal').modal('hide');
            processAlertQueue();
        });
    } else {
        $('#alertModalConfirm').hide();
    }

    $('#alertModal').modal('show').addClass('animate__animated animate__fadeIn');

    if (autoClose && !confirmCallback) {
        setTimeout(() => {
            $('#alertModal').modal('hide');
            processAlertQueue();
        }, 3000);
    }

    $('#alertModal').on('shown.bs.modal', function() {
        $('#alertModalBody').focus();
    }).on('hidden.bs.modal', function() {
        $(this).removeClass('animate__animated animate__fadeIn');
        processAlertQueue();
    });
}
const icons = {
    success: '<i class="fas fa-check-circle mr-2"></i>',
    warning: '<i class="fas fa-exclamation-triangle mr-2"></i>',
    error: '<i class="fas fa-times-circle mr-2"></i>',
    info: '<i class="fas fa-info-circle mr-2"></i>'
};
$('#alertModalBody').html(icons[type] + message);
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">