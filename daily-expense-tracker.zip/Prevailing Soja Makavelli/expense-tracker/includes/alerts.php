<?php
function setAlert($message, $type = 'info', $autoClose = false) {
    $_SESSION['alert'] = [
        'message' => $message,
        'type' => $type,
        'autoClose' => $autoClose
    ];
}

function displayAlert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        echo "<script>
            $(document).ready(function() {
                showAlert(" . json_encode($alert['message']) . ", '" . $alert['type'] . "', null, " . ($alert['autoClose'] ? 'true' : 'false') . ");
            });
        </script>";
        unset($_SESSION['alert']);
    }
}
?>