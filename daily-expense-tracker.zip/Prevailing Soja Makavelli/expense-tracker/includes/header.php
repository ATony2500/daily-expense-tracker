<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="../index.php">Expense Tracker</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $_SESSION['role'] === 'admin' ? '../admin/dashboard.php' : '../user/dashboard.php'; ?>">Dashboard</a>
                    </li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="../admin/manage_users.php">Manage Users</a></li>
                        <li class="nav-item"><a class="nav-link" href="../admin/manage_categories.php">Manage Categories</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="../user/add_expense.php">Add Expense</a></li>
                        <li class="nav-item"><a class="nav-link" href="../user/view_expenses.php">View Expenses</a></li>
                        <li class="nav-item"><a class="nav-link" href="../user/add_category.php">Add Category</a></li>
                        <li class="nav-item"><a class="nav-link" href="../user/set_budget.php">Set Budget</a></li>
                        <li class="nav-item"><a class="nav-link" href="../user/view_budget.php">View Budgets</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="../auth/logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="../auth/login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="../auth/register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <div class="container mt-4">
    <?php include 'modals.php'; ?>
    <?php displayAlert(); ?>