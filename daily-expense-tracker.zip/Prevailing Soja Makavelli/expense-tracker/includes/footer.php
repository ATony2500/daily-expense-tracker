</div> <!-- Close container from header.php -->
<footer class="bg-light text-center py-3 mt-4">
    <p>&copy; <?php echo date('Y'); ?> Daily Expense Tracker. All rights reserved.</p>
</footer>
</body>
</html>