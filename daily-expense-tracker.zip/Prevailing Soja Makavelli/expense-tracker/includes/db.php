<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$dbname = "expense_tracker";

$conn = mysqli_connect($host, $user, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function restrictToAdmin() {
    if (!isAdmin()) {
        header("Location: ../index.php");
        exit();
    }
}

require 'alerts.php';
?>